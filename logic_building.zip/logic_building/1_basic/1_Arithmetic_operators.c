//WAP to demostrate the arithmetic operators in c

#include <stdio.h>

int main(void)
{
        int a, b;
        printf("Enter first number A: ");
        scanf("%d", &a);
        printf("Enter secound number B: ");
        scanf("%d", &b);
        
        /* Arithmetic operators */

        //sum
        printf("a+b=%d \n", a+b);
        //substraction
        printf("a-b=%d \n", a-b);
        //multiplication
        printf("a*b=%d \n", a*b);
        //modulas
        printf("a%b=%d \n", a%b);
        //division
        printf("a/b=%d \n", a/b);

} 