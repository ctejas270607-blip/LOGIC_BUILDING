#include <stdio.h>

int main(void){

    int n=11;
    for(int i = 1; i <= 10; i++){
        printf("%d x %d = %d\n",n,i,(i*n));
    }
}